# -*- coding: utf-8 -*-
module Hijiki::DcmgrResource::V1203
  class StorageNode < Base
    include Hijiki::DcmgrResource::Common::ListMethods
  end
end
