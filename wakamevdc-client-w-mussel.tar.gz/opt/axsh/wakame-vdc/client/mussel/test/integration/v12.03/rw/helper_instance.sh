#!/bin/bash
#
# requires:
#   bash
#

## include files

## variables

## functions

### instance

function oneTimeSetUp() {
  create_instance
}

function oneTimeTearDown() {
  destroy_instance
}
