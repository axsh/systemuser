# bash/zsh completion support for mussel

## Installation

1. Copy this file to somewhere (e.g. `~/.mussel-completion.bash`).
2. Add the following line to your `.bashrc/.zshrc`:

```
source ~/.mussel-completion.bash
```
